#ifndef __DLIST_H__
#define __DLIST_H__

#include "Common.h"

/**
 * The fields of this structure are private and they should never be accessed
 * directly by client code.
 */
typedef struct _DList {
        void   *data;
        struct _DList *next;
        struct _DList *previous;
} DList;

typedef enum {
        DLIST_TRAVERSAL_ORDER_FORWARD,
        DLIST_TRAVERSAL_ORDER_REWARD
} DListTraversalOrder;

#define dlist_data(l)           (l)->data
#define dlist_has_next(l)       (((l) != NULL) && ((l)->next != NULL))
#define dlist_next(l)           (l)->next
#define dlist_has_previous(l)   (((l) != NULL) && ((l)->previous != NULL))
#define dlist_previous(l)       (l)->previous

#define dlist_is_empty(l)       ((l) == NULL)

/**
 * Appends and element to the end of the list.
 *
 * Note: an empty list is represented by a (DList *) containing a NULL value.
 */
DList *dlist_append (DList *list, void *data);

/**
 * Prepends and element at the beginning of the list, in O(1) time.
 *
 * Note: an empty list is represented by a (DList *) containing a NULL value.
 */
DList *dlist_prepend (DList *list, void *data);

/**
 * Returns the last node in the list.
 */
DList *dlist_last (DList *list);

/**
 * Shallow destruction of the list.
 *
 * The data that were pointed to by the list is not freed, but only the nodes
 * of the list itself.
 */
void  dlist_destroy (DList *list);

/**
 * Removes a node from the list and frees the memory of the node.
 *
 * Returns the new start of the list without the deleted node. If the node
 * was not part of the list, returns the original list.
 */
DList *dlist_delete_link (DList *list, DList *node);

/**
 * Iterates over each element of the list in the given order applying a function
 * to each one.
 */
void  dlist_foreach (DList *list,
                          DListTraversalOrder order,
                          VisitorFunc visit,
                          void *extra_data);

#endif /* __DLIST_H__ */
