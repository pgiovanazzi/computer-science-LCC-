#ifndef __SLIST_H__
#define __SLIST_H__

#include <stddef.h>
#include "Common.h"

/**
 * The fields of this structure are private and they should never be accessed
 * directly by client code.
 */
typedef struct _SList {
        void   *data;
        struct _SList *next;
} SList;

#define slist_data(l)       (l)->data
#define slist_next(l)       (l)->next
#define slist_is_empty(l)   ((l) == NULL)

/**
 * Appends and element to the end of the list, in O(n) time.
 *
 * Note: an empty list is represented by an (SList *) containing a NULL value.
 */
SList *slist_append (SList *list, void *data);

/**
 * Prepends and element at the beginning of the list, in O(1) time.
 *
 * Note: an empty list is represented by an (SList *) containing a NULL value.
 */
SList *slist_prepend (SList *list, void *data);

/**
 * Shallow destruction of the list.
 *
 * The data that were pointed to by the list is not freed, but only the nodes
 * of the list itself.
 */
void  slist_destroy (SList *list);

/**
 * Iterates over all the elements pointed to by the list and applying a function
 * 'visit' to each one of them.
 */
void  slist_foreach (SList *list, VisitorFunc visit, void *extra_data);

/**
 * Returns the number of items pointed to by the list.
 */
size_t slist_length (const SList *list);

/**
 * Inserts a data in the specified position.
 *
 * Position indexes are increasing numbers starting from 0, with 0 corresponding
 * to the beginning of the list.
 */
SList *slist_insert (SList *list, unsigned int position, const void *data);

/**
 * Returns the index of the first occurrence of a referenced data, or -1 if
 * that data is not referenced by any node of the list.
 */
int slist_index(const SList *list, const void *data);

/**
 * Returns a new list which is the intersection of the two given lists.
 */
SList *slist_intersect (const SList *l1, const SList *l2);

/**
 * Returns a new list which is the intersection of the two given lists, and
 * using a custom comparation function to compare the items of that two lists.
 */
SList *slist_intersect_custom (const SList *l1, const SList *l2, EqualsFunc equals);

#endif /* __SLIST_H__ */
