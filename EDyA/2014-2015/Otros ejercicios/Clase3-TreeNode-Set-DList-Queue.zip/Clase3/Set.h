#ifndef __SET_H__
#define __SET_H__

#include "SList.h"
#include "Common.h"

/**
 * The fields of this structure are private and they should never be accessed
 * directly by client code.
 */
typedef struct {
        SList *items;
} Set;

#define set_is_empty(set)  ((set)->items == NULL)

Set     *set_new           (void);

void    set_add            (Set *set, void *item);
int     set_contains       (Set *set, void *item);
void    set_remove         (Set *set, void *item);
void    set_destroy        (Set *set);
void    set_foreach        (Set *set, VisitorFunc visit, void *extra_data);

#endif /* __SET_H__ */
