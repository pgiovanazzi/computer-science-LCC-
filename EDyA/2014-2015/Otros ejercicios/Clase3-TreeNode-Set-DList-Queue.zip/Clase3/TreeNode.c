#include "TreeNode.h"
#include "Mem.h"
#include "Log.h"

TreeNode *tree_node_new (void *data)
{
         TreeNode *result = mem_new(TreeNode,1);
         result->data = data;
         result->children = NULL;
         return result;
}

void tree_node_add_child (TreeNode *parent, TreeNode *child)
{
         log_return_if_fail(parent != NULL);
         log_return_if_fail(child != NULL);

         /* FIXME make sure we are building a tree */
         parent->children = slist_append(parent->children, child);
}

typedef void (*TreeNodeVisitor) (TreeNode *node, void *extra_data);

static void tree_node_foreach_node (TreeNode *tree, TreeNodeVisitor visit, void *extra_data)
{
         SList *children = tree->children;
         while (children) {
               TreeNode *child = (TreeNode*)children->data;
               tree_node_foreach_node(child, visit, extra_data);
               children = slist_next(children);
         }
         visit(tree, extra_data);
}

static void tree_node_free(TreeNode *node, void *extra_data)
{
         mem_free(node);
}

void tree_node_destroy (TreeNode *tree)
{
         log_return_if_fail(tree != NULL);

         /* This works because tree_node_foreach_node is depth-first */
         tree_node_foreach_node(tree, tree_node_free, NULL);
}

int tree_node_has_descendant (TreeNode *ancestor, TreeNode *descendant)
{
         log_return_val_if_fail(ancestor != NULL, -1);
         log_return_val_if_fail(descendant != NULL, -1);

         /* TODO implement */

         return -1;
}

void     tree_node_foreach (TreeNode *tree, TreeNodeVisitOrder order,
                           VisitorFunc visit, void *extra_data)
{
         log_return_if_fail(tree != NULL);
         log_return_if_fail(visit != NULL);

         if (order == TREE_NODE_VISIT_ORDER_NODE_FIRST) {
                  visit(tree->data, extra_data);
         }
         /* Exercise: implement it using only slist_foreach */
         SList *children = tree->children;
         while (children) {
               TreeNode *child = (TreeNode*)children->data;
               tree_node_foreach(child, order, visit, extra_data);
               children = slist_next(children);
         }
         if (order == TREE_NODE_VISIT_ORDER_CHILD_FIRST) {
                  visit(tree->data, extra_data);
         }

         /* TODO implement TREE_NODE_VISIT_ORDER_LEVEL_FIRST order */

}
