#include <stdlib.h>
#include "SList.h"
#include "Mem.h"
#include "Log.h"

SList *slist_append(SList *list, void *data)
{
      SList *newNode = mem_new(SList,1);
      SList *node;
      newNode->data = data;
      newNode->next = NULL;
      if (list == NULL) {
         return newNode;
      }
      node = list;
      while (slist_next(node) != NULL) {
            node = slist_next(node);
      }
      /* now 'node' points to the last node in the list */
      node->next = newNode;
      return list;
}

SList *slist_prepend(SList *list, void *data)
{
      SList *newNode = mem_new(SList,1);
      newNode->next = list;
      newNode->data = data;
      return newNode;
}

void  slist_destroy(SList *list)
{
      SList *nodeToDelete;
      while (list != NULL) {
            nodeToDelete = list;
            list = slist_next(list);
            mem_free(nodeToDelete);
      }
}

void  slist_foreach(SList *list, VisitorFunc visit, void *extra_data)
{
      log_return_if_fail(visit != NULL);

      SList *node = list;
      while (node != NULL) {
            visit(slist_data(node), extra_data);
            node = slist_next(node);
      }
}

size_t slist_length (const SList *list)
{
      size_t len;
      for (len = 0; list != NULL; len++, list = slist_next(list))
          ;
      return len;
}

SList *slist_insert (SList *list, unsigned int position, const void *data)
{
      /* TODO */
      return NULL;
}

int slist_index(const SList *list, const void *data)
{
      int index = -1, posibleIndex = 0;
      while (list) {
            if (slist_data(list) == data) {
                   index = posibleIndex;
                   break;
            }
            posibleIndex++;
            list = slist_next(list);
      }
      return index;
}

SList *slist_intersect (const SList *l1, const SList *l2)
{
      /* TODO */
      return NULL;
}

SList *slist_intersect_custom (const SList *l1, const SList *l2, EqualsFunc equals)
{
      /* TODO */
      return NULL;
}
