#ifndef __COMMON_H__
#define __COMMON_H__

typedef void (*VisitorFunc) (void *data, void *extra_data);

/**
 * Functions of this type should return 0 if the objects pointed to by 'a' and
 * 'b' are different, or a value different from 0 if the objects are equal.
 */
typedef int  (*EqualsFunc) (void *a, void *b);

#endif /* __COMMON_H__ */
