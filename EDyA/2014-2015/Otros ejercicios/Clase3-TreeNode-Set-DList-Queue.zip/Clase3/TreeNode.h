#ifndef __TREE_H__
#define __TREE_H__

#include <stddef.h>
#include "SList.h"

/**
 * The fields of this structure are private and they should never be accessed
 * directly by client code.
 */
typedef struct  {
        void    *data;
        SList   *children;
} TreeNode;

typedef enum {
        TREE_NODE_VISIT_ORDER_NODE_FIRST,
        TREE_NODE_VISIT_ORDER_CHILD_FIRST,
        TREE_NODE_VISIT_ORDER_LEVEL_FIRST
} TreeNodeVisitOrder;

/**
 * Creates a new tree node pointing to 'data'.
 */
TreeNode *tree_node_new (void *data);

/**
 * Adds a new child to a tree node.
 *
 * 'child' cannot be NULL. Children are added in left-to-right order.
 */
void     tree_node_add_child (TreeNode *parent, TreeNode *child);

/**
 * Shallow destruction of a tree.
 *
 * The data that were pointed to by the tree is not freed, but only the nodes
 * of the tree itself.
 */
void     tree_node_destroy (TreeNode *tree);

/**
 * Tells whether 'ancestor' has 'descendant' as one of its descendants.
 */
int      tree_node_has_descendant (TreeNode *ancestor, TreeNode *descendant);

/**
 * Applies a function to all the elements of a tree in the given order
 */
void     tree_node_foreach (TreeNode *tree, TreeNodeVisitOrder order,
                           VisitorFunc visit, void *extra_data);

#endif /* __TREE_H__ */
