#include <stdio.h>
#include <stdlib.h>
#include "DList.h"
#include "Queue.h"

static void print_char (void *data, void *extra_data)
{
      printf("%c ", *(char*)data);
}

static void test_tree_node()
{
      /* TODO */
}

static void test_set()
{
      /* TODO */
}

static void test_dlist_delete_link()
{
    char a = 'a', b = 'b', c = 'c', d = 'd', e = 'e';

    DList * l1 = NULL;
    l1 = dlist_prepend(l1, &a);
    l1 = dlist_delete_link(l1, l1);
    puts("Deleted the only node of l1");
    dlist_foreach(l1, DLIST_TRAVERSAL_ORDER_FORWARD, print_char, NULL);
    puts("");
    DList *l2 = NULL;
    l2 = dlist_prepend(l2, &b);
    l2 = dlist_prepend(l2, &c);
    l2 = dlist_delete_link(l2, l2);
    puts("Deleted the 1st node of l2");
    dlist_foreach(l2, DLIST_TRAVERSAL_ORDER_FORWARD, print_char, NULL);
    puts("");
    DList *l3 = NULL;
    l3 = dlist_prepend(l3, &d);
    l3 = dlist_prepend(l3, &e);
    l3 = dlist_delete_link(l3, l3->next);
    puts("Deleted the 2nd node of l3");
    dlist_foreach(l3, DLIST_TRAVERSAL_ORDER_FORWARD, print_char, NULL);
    puts("");
}

static void test_dlist()
{
    char a = 'a', b = 'b', c = 'c', d = 'd';

    DList * list = NULL;
    list = dlist_prepend(list, &a);
    list = dlist_prepend(list, &b);
    list = dlist_prepend(list, &c);
    list = dlist_prepend(list, &d);
    dlist_foreach(list, DLIST_TRAVERSAL_ORDER_FORWARD, print_char, NULL);
    puts("");
    DList *last = dlist_last(list);
    dlist_foreach(last, DLIST_TRAVERSAL_ORDER_REWARD, print_char, NULL);
    puts("");
    dlist_destroy(list);
    test_dlist_delete_link();
}

static void test_queue()
{
    char a = 'a', b = 'b', c = 'c', d = 'd';

    Queue *queue = queue_new();
    queue_push(queue, &a);
    queue_push(queue, &b);
    queue_push(queue, &c);
    queue_push(queue, &d);
    char *cc = (char*) queue_pop(queue);
    printf("pop: %c\n", *cc);
    queue_foreach(queue, print_char, NULL);
    puts("");
    queue_destroy(queue);      
}

int main(int argc, char *argv[])
{
    test_tree_node();
    test_set();
    test_dlist();
    test_queue();
    system("PAUSE");
    return 0;
}
