#ifndef __QUEUE_H__
#define __QUEUE_H__

#include "DList.h"
#include "Common.h"

/**
 * The fields of this structure are private and they should never be accessed
 * directly by client code.
 */
typedef struct {
        DList *head;
        DList *tail;
} Queue;

/**
 * Tells whether the queue is empty.
 */
#define queue_is_empty(queue)   dlist_is_empty((queue)->tail)

/**
 * Creates a new, empty queue.
 */
Queue *queue_new           (void);

/**
 * Destroys a queue and releases the memory occupied by it.
 */
void  queue_destroy        (Queue *queue);

/**
 * Adds and element to the queue.
 */
void  queue_push           (Queue *queue, void *data);

/**
 * Returns the next element in que queue, or NULL if the queue is empty.
 */
void  *queue_pop           (Queue *queue);

/**
 * Iterates over all the items in the queue, in the order they will be served.
 */
void  queue_foreach        (Queue *queue, VisitorFunc visit, void *extra_data);

#endif /* __QUEUE_H__ */
