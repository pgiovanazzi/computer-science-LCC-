#ifndef __SLIST_H__
#define __SLIST_H__

#include "Common.h"

/**
 * The fields of this structure are private and they should never be accessed
 * directly by client code.
 */
typedef struct _SList {
        void   *data;
        struct _SList *next;
} SList;

#define slist_data(l)       (l)->data
#define slist_next(l)       (l)->next

/**
 * Appends and element to the end of the list, in O(n) time.
 *
 * Note: an empty list is represented by an (SList *) containing a NULL value.
 */
SList *slist_append(SList *list, void *data);

/**
 * Prepends and element at the beginning of the list, in O(1) time.
 *
 * Note: an empty list is represented by an (SList *) containing a NULL value.
 */
SList *slist_prepend(SList *list, void *data);

/**
 * Shallow destruction of the list.
 *
 * The data that were pointed to by the list is not freed, but only the nodes
 * of the list itself.
 */
void  slist_destroy(SList *list);

void  slist_foreach(SList *list, VisitorFunc visit, void *extra_data);

#endif /* __SLIST_H__ */
