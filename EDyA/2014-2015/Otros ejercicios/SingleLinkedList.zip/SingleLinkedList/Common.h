
typedef void (*VisitorFunc) (void *data, void *extra_data);
