#include <stdio.h>
#include <stdlib.h>
#include "SList.h"
#include "Log.h"

static void print_int (void *data, void *extra_data)
{
       printf("%d ", *(int*)data);
}

int main(int argc, char *argv[])
{
    int a = 1, b = 2, c = 3, d = 4;

    SList *list = NULL;
    list = slist_prepend(list, &a);
    list = slist_prepend(list, &b);
    list = slist_prepend(list, &c);
    list = slist_append(list, &d);
    slist_foreach(list, print_int, NULL);
    puts("");
    log_return_val_if_fail(1 > 2, -1);
    slist_destroy(list);

    system("PAUSE");
    return 0;
}
