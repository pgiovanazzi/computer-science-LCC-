#include "Heap.h"
#include "Mem.h"
#include "Log.h"

#define HEAP_INITIAL_ALLOCATED_NODES    1024

/*
 * The first node in the array is not part of the tree, and is used to store
 * the number of nodes instead.
 */
#define heap_length(heap)               (*((int*)(heap)->nodes))

Heap *heap_new (OrderFunc compare_nodes, size_t node_size)
{
     Heap *heap;

     log_return_val_if_fail (compare_nodes != NULL, NULL);
     /*
      * We require a node size of at least the size of an int since we
      * store the number of nodes in nodes[0] as an int.
      */
     log_return_val_if_fail (node_size >= sizeof(int), NULL);

     heap = mem_new(Heap,1);
     heap->nodes = mem_new(unsigned char, HEAP_INITIAL_ALLOCATED_NODES * node_size);
     heap->node_size = node_size;
     heap->allocated_nodes = HEAP_INITIAL_ALLOCATED_NODES;
     heap->number_of_elements = 0;
     heap->compare_nodes = compare_nodes;
     heap_length(heap) = 0;

     return heap;
}

void  heap_insert (Heap *heap, void *data)
{
      /* check if we must resize the 'nodes' array */

      /* insert the node */      

      /* heapify */
}

void *heap_delete (Heap *heap)
{
      log_return_val_if_fail (heap != NULL, NULL);

      /* TODO */

      return NULL;
}

void  heap_destroy (Heap *heap)
{
      log_return_if_fail (heap != NULL);

      mem_free(heap->nodes);
      mem_free(heap);
}
