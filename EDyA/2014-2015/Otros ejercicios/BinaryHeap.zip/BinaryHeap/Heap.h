#ifndef __HEAP_H__
#define __HEAP_H__
#include <stddef.h>
#include "Common.h"

typedef struct {
        void        *nodes;             /* array of nodes in the tree */
        size_t      node_size;          /* size in bytes of each node */
        size_t      allocated_nodes;    /* number of nodes allocated in the 'nodes' array */
        size_t      number_of_elements; /* number of nodes stored in the 'nodes' array.
                                           less than or equal than 'allocated_nodes' */
        OrderFunc   compare_nodes;
} Heap;

Heap *heap_new (OrderFunc compare_nodes, size_t node_size);

void  heap_insert (Heap *heap, void *data);
void *heap_delete (Heap *heap);

void  heap_destroy (Heap *heap);

#endif /* __HEAP_H__ */
