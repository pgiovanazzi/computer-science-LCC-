#ifndef __MEM_H__
#define __MEM_H__

#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>

/* TODO in the future we can add more custom (and customizable) behavior */

#define mem_new(struct_type,n_structs)                          \
(struct_type *) ({                                              \
        size_t __n = (size_t)(n_structs);                       \
        void *__p = malloc(sizeof(struct_type)*(__n));          \
        if (__p == NULL) {                                      \
           fprintf(stderr, "Error[%s:%d]: Failed to allocate memory\n", \
                           __FILE__, __LINE__);                 \
           exit(0);                                             \
        }                                                       \
        __p;                                                    \
})

#define mem_free(p)                                                   \
{                                                                     \
        if (p == NULL) {                                              \
           fprintf(stderr, "Warning[%s:%d]: trying to free null pointer\n", \
                           __FILE__, __LINE__);                       \
        }                                                             \
        free(p);                                                      \
}

#endif /* __MEM_H__ */
