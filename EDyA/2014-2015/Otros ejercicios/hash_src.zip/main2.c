#include <stdio.h>
#include <stdlib.h>
#include "hashtable.h"

int equals(void *key1, void *key2) {
  int *p = key1;
  int *q = key2;

  return *p == *q;
}

unsigned int hash(void *key) {
  int *p = key;
  return *p % 10;
}

int main(void) {
  int x = 42, y = 42, z = 3;
  Hashtable *ht = hashtable_new(10, hash, equals);

  hashtable_insert(ht, &x, &z);

  printf("z : %d\n", *((int *)hashtable_lookup(ht, &x)));
  printf("z : %d\n", *((int *)hashtable_lookup(ht, &y)));

  hashtable_delete(ht, &x);

  hashtable_destroy(ht);

  return 0;
}
