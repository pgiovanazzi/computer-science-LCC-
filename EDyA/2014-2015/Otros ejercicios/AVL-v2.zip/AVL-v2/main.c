#include <stdio.h>
#include <stdlib.h>
#include "BST_AVL.h"

static int compare_int (const void *x, const void *y) {
        int _x = *(int*)x;
        int _y = *(int*)y;
        return (_x < _y) ? -1 : ((_x > _y) ? 1 : 0);
}

static void test_bst_avl_left_left_case()
{
        int i = 44, j = 17, k = 5;
        BST_AVL *avl = bst_avl_new(compare_int);
        bst_avl_insert(avl, &i);
        bst_avl_insert(avl, &j);
        bst_avl_insert(avl, &k);
        bst_avl_destroy(avl);
}

static void test_bst_avl()
{
        test_bst_avl_left_left_case();
}

int main(int argc, char *argv[])
{
        test_bst_avl();
        return 0;
}
