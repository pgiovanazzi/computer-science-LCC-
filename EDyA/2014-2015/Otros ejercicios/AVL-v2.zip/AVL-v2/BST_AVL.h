#ifndef __BST_AVL__
#define __BST_AVL__
#include "Common.h"

typedef struct _BST_AVL_Node BST_AVL_Node;

typedef struct {
        BST_AVL_Node  *root;
        OrderFunc     order;
} BST_AVL;

BST_AVL *bst_avl_new (OrderFunc order);

void    bst_avl_insert (BST_AVL *bst, void *data);
int     bst_avl_lookup (BST_AVL *bst, void *data);
void    bst_avl_remove (BST_AVL *bst, void *data);
void    bst_avl_foreach (BST_AVL *bst, VisitorFunc visit, void *extra_data);

void    bst_avl_destroy (BST_AVL *bst);

#endif /* __BST_AVL__ */
