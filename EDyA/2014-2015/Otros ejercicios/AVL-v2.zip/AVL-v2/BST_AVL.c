#include <assert.h>
#include "BST_AVL.h"
#include "Mem.h"
#include "Log.h"

struct _BST_AVL_Node {
        void          *data;
        BST_AVL_Node  *left;
        BST_AVL_Node  *right;
        unsigned int  height;
};

#define has_left_child(node)      ((node)->left != NULL)
#define has_right_child(node)     ((node)->right != NULL)
#define left_child(node)          ((node)->left)
#define right_child(node)         ((node)->right)

#define balance_factor(node)      (((left_child(node)) ? left_child(node)->height : 0) \
                                 - ((right_child(node)) ? right_child(node)->height : 0))
                                 
#define MAX_CHILDREN_HEIGHT(node) (MAX(left_child(node) ? left_child(node)->height : 0, \
                                       right_child(node) ? right_child(node)->height : 0))

static BST_AVL_Node *bst_avl_node_new (void *data)
{
        BST_AVL_Node *newNode = mem_new(BST_AVL_Node,1);
        newNode->data = data;
        newNode->left = newNode->right = NULL;
        newNode->height = 1;
        return newNode;
}

BST_AVL *bst_avl_new (OrderFunc order)
{
        BST_AVL *bst;

        log_return_val_if_fail (order != NULL, NULL);

        bst = mem_new(BST_AVL, 1);
        bst->root = NULL;
        bst->order = order;

        return bst;
}

/*
 * Performs the specified rotation and returns the new root
 */
static BST_AVL_Node *bst_avl_node_rotate_right (BST_AVL_Node *node)
{
        BST_AVL_Node *oldLeft = left_child(node);
        left_child(node) = right_child(left_child(node));
        right_child(oldLeft) = node;
        node->height = 1 + MAX_CHILDREN_HEIGHT(node);
        oldLeft->height = 1 + MAX_CHILDREN_HEIGHT(oldLeft);
        return oldLeft;
}

/*
 * Performs the specified rotation and returns the new root
 */
static BST_AVL_Node *bst_avl_node_rotate_left (BST_AVL_Node *node)
{
        BST_AVL_Node *oldRight = right_child(node);
        right_child(node) = left_child(right_child(node));
        left_child(oldRight) = node;
        node->height = 1 + MAX_CHILDREN_HEIGHT(node);
        oldRight->height = 1 + MAX_CHILDREN_HEIGHT(oldRight);
        return oldRight;
}

static void
bst_avl_node_insert (BST_AVL_Node **parent, BST_AVL_Node *node, void *data, OrderFunc order) {
        fprintf(stderr, "DEBUG: balance factor: %d\n", balance_factor(node));
        //assert(balance_factor(node) <= 2 && balance_factor(node) >= -2);
        if (order(data, node->data) < 0) {
                /* goes into left branch */
                if (left_child(node) == NULL) {
                        /* new leaf on the left */
                        fprintf(stderr, "DEBUG: inserting left leaf\n");
                        left_child(node) = bst_avl_node_new(data);
                } else {
                        /* recursively insert it in the left branch */
                        fprintf(stderr, "DEBUG: inserting recursively into left branch\n");
                        bst_avl_node_insert(&left_child(node), left_child(node), data, order);
                }
                fprintf(stderr, "DEBUG: current node height is %d, max children height is %d\n",
                                node->height, MAX_CHILDREN_HEIGHT(node));
                node->height = 1 + MAX_CHILDREN_HEIGHT(node);
                fprintf(stderr, "DEBUG: height updated to %d\n", node->height);
                /* check balance */
                if (balance_factor(node) == 2) {
                        /* must re-balance */
                        if (balance_factor(left_child(node)) == -1) {
                                /* left-right case */
                                fprintf(stderr, "DEBUG: re-balancing [left-right case]\n");
                                left_child(node) = bst_avl_node_rotate_left(left_child(node));
                        }
                        /* left-left case */
                        fprintf(stderr, "DEBUG: re-balancing [left-left case]\n");
                        *parent = bst_avl_node_rotate_right(node);
                        /* now should be balanced */
                        fprintf(stderr, "DEBUG: height updated to %d after re-balancing\n",
                                        node->height);
                }
        } else if (order(data, node->data) > 0) {
                /* goes into right branch */
                
                /* === TODO === */
                
        } else {
                /* already in the bst, ignore the duplicate */
        }
}

void bst_avl_insert (BST_AVL *bst, void *data)
{
        log_return_if_fail (bst != NULL);

        if (bst->root == NULL) {
                bst->root = bst_avl_node_new(data);
        } else {
                bst_avl_node_insert(&bst->root, bst->root, data, bst->order);
        }
}

static int
bst_avl_lookup_unchecked (BST_AVL_Node *node, void *data, OrderFunc order)
{
        if (order(data, node->data) == 0) {
                return TRUE;
        } else {
                if (order(data, node->data) < 0) {
                        if (has_left_child(node)) {
                                return bst_avl_lookup_unchecked(left_child(node), data, order);
                        } else {
                                return FALSE;
                        }
                } else {
                        /* data > node->data */
                        if (has_right_child(node)) {
                                return bst_avl_lookup_unchecked(right_child(node), data, order);
                        } else {
                                return FALSE;
                        }
                }
        }
}

int bst_avl_lookup (BST_AVL *bst, void *data)
{
        log_return_val_if_fail (bst != NULL, FALSE);

        return bst_avl_lookup_unchecked (bst->root, data, bst->order);
}

void bst_avl_remove (BST_AVL *bst, void *data)
{
        log_return_if_fail (bst != NULL);
        /* TODO */
}

static void
bst_avl_foreach_node (BST_AVL_Node *node, VisitorFunc visit, void *extra_data)
{
        if (node->left != NULL) {
                bst_avl_foreach_node (node->left, visit, extra_data);
        }
        visit(node->data, extra_data);
        if (node->right != NULL) {
                bst_avl_foreach_node (node->right, visit, extra_data);
        }
}

void bst_avl_foreach (BST_AVL *bst, VisitorFunc visit, void *extra_data)
{
        log_return_if_fail(bst != NULL);
        log_return_if_fail(visit != NULL);
        bst_avl_foreach_node (bst->root, visit, extra_data);
}

void bst_avl_destroy (BST_AVL *bst)
{
        log_return_if_fail (bst != NULL);
        /* TODO */
}
