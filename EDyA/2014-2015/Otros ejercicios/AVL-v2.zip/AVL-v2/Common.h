#ifndef __COMMON_H__
#define __COMMON_H__

#ifndef FALSE
#define FALSE       (0)
#define TRUE        (!FALSE)
#endif

#ifndef MAX
#define MAX(a,b)    ((a) < (b) ? (b) : (a))
#define MIN(a,b)    ((a) < (b) ? (a) : (b))
#endif

/**
 * Type of the functions used to visit elements of a collection.
 */
typedef void (*VisitorFunc)     (void *data, void *extra_data);

/**
 * Type of the functions used to visit the (key,value) pairs of a
 * hash table.
 */
typedef void (*HTVisitorFunc)   (void *key, void *value, void *extra_data);

/**
 * Functions of this type should return 0 if the objects pointed to by 'a' and
 * 'b' are different, or a value different from 0 if the objects are equal.
 */
typedef int (*EqualsFunc) (const void *a, const void *b);

/**
 * Functions that return -1 if a is less than b, 0 if a equals b or 1 if 
 * a is greater than b.
 */
typedef int (*OrderFunc)  (const void *a, const void *b);

#endif /* __COMMON_H__ */
