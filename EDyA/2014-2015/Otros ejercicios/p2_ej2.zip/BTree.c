#include <stdlib.h>
#include "BTree.h"

BTree btree_create(int data, BTree left, BTree right)
{
	BTree newNode = malloc(sizeof(BTNode));
	btree_data(newNode) = data;
	btree_left(newNode) = left;
	btree_right(newNode) = right;
	return newNode;
}

void  btree_destroy(BTree node)
{
	if (node != NULL) {
		btree_destroy(btree_left(node));
		btree_destroy(btree_right(node));
		free(node);
	}
}

void  btree_foreach(BTree node, VisitorFuncInt visit, void *extra_data)
{
	if (node != NULL) {
		visit(btree_data(node), extra_data);
		btree_foreach(btree_left(node), visit, extra_data);
		btree_foreach(btree_right(node), visit, extra_data);
	}
}


static void contar_nodos(int data, void *extra_data) {
	*((int*)extra_data) += 1;
}

int btree_count(BTree tree) {
	int count = 0;
	btree_foreach(tree, contar_nodos, &count);
	return count;
}


int btree_height(BTree tree) {
	// Caso Base	
	if (btree_empty() == tree)
		return 0;

	// Caso recursivo
	int l_height = btree_height(btree_left(tree));
	int r_height = btree_height(btree_right(tree));

	return 1 + (l_height > r_height ? l_height : r_height);
}

