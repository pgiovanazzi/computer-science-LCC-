#include <string.h> /* for memcpy() */
#include "my_qsort.h"
#include "Log.h"

static void swap (int *x, int *y, size_t element_size)
{
    unsigned char temp[MAX_ELEMENT_SIZE];

    log_return_if_fail (element_size <= MAX_ELEMENT_SIZE);

    memcpy(temp, x, element_size);
    memcpy(x, y, element_size);
    memcpy(y, temp, element_size);
}
 
static int partition (void *a, int p, int r, size_t element_size,
                       int (*comparator) ( const void *, const void *))
{
    void *pivot = a + p * element_size;
    int i = p - 1;
    int j = r + 1;

    while(1) {
        do {
            j--;
        } while (comparator(a + j * element_size, pivot) > 0);
        do {
            i++;
        } while (comparator(a + i * element_size, pivot) < 0);
        if (i < j) {
            swap(a + i * element_size, a + j * element_size, element_size);
        } else {
            return j;
        }
    }
}
 
static void quicksort (void *a, int p, int r, size_t element_size,
                       int (*comparator) ( const void *, const void *))
{
   int q;
   if (p < r) {
      q = partition(a, p, r, element_size, comparator);
      quicksort(a, p, q, element_size, comparator);
      quicksort(a, q+1, r, element_size, comparator);
   }
}

void my_qsort (void *base, size_t num, size_t size,
               int (*comparator) (const void *, const void *))
{
    if (num == 0) {
        return;
    }
    quicksort (base, 0, num-1, size, comparator);
}
