#include <stdio.h>
#include "my_qsort.h"

static int int_equals (const void *a, const void *b)
{
    int x = *(int*)a;
    int y = *(int*)b;

    fprintf(stderr, "DEBUG: comparing %d and %d\n", x, y);
    if (x < y) {
        return -1;
    } else if (x > y) {
        return 1;
    } else {
        return 0;
    }
}

int main(int argc, char *argv[])
{
    int i;
    int arr[] = { 5, 3, 2, 6, 4, 1, 3, 7 };
    size_t arr_size = sizeof(arr)/sizeof(arr[0]);

    my_qsort(arr, arr_size, sizeof(arr[0]), int_equals);
    for (i = 0; i < arr_size; i++) {
        printf("%d ", arr[i]);
    }
    puts("");

    system("PAUSE");	
    return 0;
}
