#ifndef __MY_QSORT_H__
#define __MY_QSORT_H__
#include <stdlib.h>

#define MAX_ELEMENT_SIZE    0x1000  /* 4KB */

void my_qsort (void *base, size_t num, size_t size,
               int (*comparator) (const void *, const void *));

#endif /* __MY_QUICKSORT_H__ */
