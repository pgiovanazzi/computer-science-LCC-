#ifndef __LOG_H__
#define __LOG_H__

#include <stdio.h>

#define log_return_if_fail(predicate)                                 \
{                                                                     \
        if (!(predicate)) {                                           \
           fprintf(stderr, "Warning[%s:%d]: assertion '%s' failed\n", \
                           __FILE__, __LINE__, #predicate);           \
           return;                                                    \
        }                                                             \
}

#define log_return_val_if_fail(predicate,val)                         \
{                                                                     \
        if (!(predicate)) {                                           \
           fprintf(stderr, "Warning[%s:%d]: assertion '%s' failed\n", \
                           __FILE__, __LINE__, #predicate);           \
           return (val);                                              \
        }                                                             \
}

#endif /* __LOG_H__ */
