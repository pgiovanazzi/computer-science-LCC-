include <stdio.h>
#include <stdlib.h>
#include "GQueue.h"
// GQueue -- Listas generales

// Crea una cola.
GQueue gqueue_create(){
    return NULL;
}
//toma una cola e indica si vacía.
int gqueue_empty(GQueue queue){
    return NULL == queue;
};

//Toma una cola y devuelve el elemento en la primera posición.
void *gqueue_front(GQueue queue){
    if (NULL == queue) {
        fprintf(stderr, "Arrgh! Cola vacía.\n");
        exit(1);
    }
    return queue->data;
}

//Toma una cola y un elemento y agrega el elemento al fin de la cola.
GQueue gqueue_enqueue(GQueue queue, void *data){

    if(NULL == queue){
        GQueue newNode = (GQueue) malloc(sizeof(GQueueNode));

        newNode->data = data;
        newNode->next = NULL;

        if (NULL == newNode) {
            fprintf(stderr, "Arrgh! Memoria insuficiente.\n");
            exit(1);
        }
        queue = newNode;
    } else {
        queue->next = gqueue_enqueue(queue->next, data);
    }
    return queue;
}

//Toma una cola y le quita su primer elemento.
GQueue gqueue_dequeue(GQueue queue){
    if (NULL == queue) {
        fprintf(stderr, "Arrgh! Cola vacía.\n");
        exit(1);
    }
    return queue->next;
}

void gqueue_print(GQueue queue, PrintFunc print){
    if (NULL == queue){
        return;
    }
    print(queue->data);
    gqueue_print(queue->next, print);
}

//Toma una cola y la destruye
void gqueue_destroy(GQueue queue){
    GQueue aux;
    while(NULL != queue){
        aux = queue;
        queue = queue->next;
        free(aux);
    }
}
