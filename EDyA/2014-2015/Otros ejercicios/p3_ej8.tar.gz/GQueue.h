#ifndef __GQUEUE_H__
#define __GQUEUE_H__
typedef void (*PrintFunc) (void *data);

// Colas generales

typedef struct _GQueueNode{
    void *data;
    struct _GQueueNode *next;
} GQueueNode;

typedef GQueueNode *GQueue;

// Crea una cola.
GQueue gqueue_create();

//toma una cola e indica si esta vacía.
int gqueue_empty(GQueue);

//toma una cola y devuelve el elemento en la primera posición.
void *gqueue_front(GQueue);

//Toma una cola y un elemento y agrega el elemento al fin de la cola.
GQueue gqueue_enqueue(GQueue, void*);

//Toma una cola y le quita su primer elemento.
GQueue gqueue_dequeue(GQueue);

void gqueue_print(GQueue, PrintFunc);

//Toma una cola y la destruye
void gqueue_destroy(GQueue);

#endif /* __GQUEUE_H__ */
