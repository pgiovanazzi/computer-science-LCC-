#include <stdio.h>
#include <stdlib.h>
#include "GQueue.h"
#include "BTree.h"

void btree_foreach_level(BTree tree, VisitorFuncInt visit, void *extra_data){
    if (!tree)
        // Árbol vacio, nada a quien visitar
        return;

    // Definimos una cola genérica
    // donde vamos a guardar los nodos a visitar
    // en el orden deseado
    GQueue queue = gqueue_create();
    GQueue next_queue = gqueue_create();

    // Metemos el nodo de la raíz en la cola de nodos a visitar
    // ya que es el primero que visitaremos
    queue = gqueue_enqueue(queue, tree);

    BTree aux_tree;
    while (!gqueue_empty(queue)){
        // Mientras existan nodos en la cola pendientes de visitar
        // tomamos el primero de los nodos a visitar
        // NOTE: las colas genéricas guardan un puntero
        // a void por lo que es necesario hacer un cast
        // antes de utilizar la información encolada
        aux_tree = (BTree) gqueue_front(queue);
        // Quitamos el elemento de la cola
        queue = gqueue_dequeue(queue);

        // Visitamos el dato correspondiente al nodo
        visit(btree_data(aux_tree), extra_data);

        if (btree_left(aux_tree))
            // Si hay elementos a la izquierda, van a la lista del siguiente nivel a visitar
            next_queue = gqueue_enqueue(next_queue, btree_left(aux_tree));
        if (btree_right(aux_tree))
            // Si hay elementos a la izquierda, van a la lista del siguiente nivel a visitar
            next_queue = gqueue_enqueue(next_queue, btree_right(aux_tree));

        if (gqueue_empty(queue)){
            // Si ya no quedan más en este nivel, pasamos al siguiente
            queue = next_queue;
            // Limpiamos la lista de siguientes
            next_queue = NULL;
            printf("\n");
        }
    }
    // Liberamos la memoria utilizada para queue
    gqueue_destroy(queue);
    gqueue_destroy(next_queue);

}

static void print_int (int data, void *extra_data){
	printf("%d ", data);
}

int main(int argc, char *argv[]){
    BTree ll = btree_create(1, btree_empty(), btree_empty());
    BTree l = btree_create(2, ll, btree_empty());
    BTree rr = btree_create(5, btree_empty(), btree_empty());
    BTree rii = btree_create(7, btree_empty(), btree_empty());
    BTree ri = btree_create(6, rii, btree_empty());
    BTree r = btree_create(3, ri, rr);
    BTree root = btree_create(4, l, r);

    // Imprimios el árbol anterior por niveles
    btree_foreach_level(root, print_int, NULL);
    puts(" ");

    // Liberamos la memoria utilizada para el árbol
    btree_destroy(root);
    return 1;
}
